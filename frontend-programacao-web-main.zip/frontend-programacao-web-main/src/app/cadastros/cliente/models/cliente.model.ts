export class Cliente {
  id?:number;
  nome!:string;
}
